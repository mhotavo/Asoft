<?php

$db = new Conexion();
include(HTML_DIR . 'index/index.php');
$db->close();
?>
